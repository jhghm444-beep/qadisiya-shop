# قادسية شوب

تطبيق سوق محلي مبني بـ Flutter، بواجهة عربية RTL.

## البناء

المشروع يحتوي على ملفات Android وملف `codemagic.yaml` للبناء السحابي.

يمكن رفع المجلد إلى GitHub ثم ربطه بخدمة Codemagic وبناء APK من workflow باسم `android-apk`.

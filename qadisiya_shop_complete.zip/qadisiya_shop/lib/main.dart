import 'package:flutter/material.dart';

void main() => runApp(const QadisiyaShopApp());

class Ad {
  final String title, price, city, category, description;
  final IconData icon;
  bool favorite;
  Ad({
    required this.title,
    required this.price,
    required this.city,
    required this.category,
    required this.description,
    required this.icon,
    this.favorite = false,
  });
}

class QadisiyaShopApp extends StatelessWidget {
  const QadisiyaShopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'قادسية شوب',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1A365D)),
        scaffoldBackgroundColor: const Color(0xFFF7F9FC),
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  String search = '';

  final List<Ad> ads = [
    Ad(title: 'آيفون 15 برو', price: '950 ألف د.ع', city: 'الديوانية', category: 'إلكترونيات',
        description: 'جهاز نظيف وبحالة ممتازة، التواصل مباشر مع البائع.', icon: Icons.phone_iphone),
    Ad(title: 'غسالة أوتوماتيك', price: '450 ألف د.ع', city: 'الديوانية', category: 'أجهزة منزلية',
        description: 'غسالة بحالة جيدة، جاهزة للاستخدام.', icon: Icons.local_laundry_service),
    Ad(title: 'بدلة رجالية', price: '75 ألف د.ع', city: 'الديوانية', category: 'أزياء وموضة',
        description: 'بدلة أنيقة ومقاسات متعددة.', icon: Icons.checkroom),
    Ad(title: 'خدمة صيانة مكيفات', price: 'حسب العمل', city: 'الديوانية', category: 'منزل وخدمات',
        description: 'صيانة وتنظيف مكيفات داخل الديوانية.', icon: Icons.build),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _favorites(),
      const MessagesScreen(),
      _profile(),
    ];
    return Scaffold(
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'الرسائل'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
      floatingActionButton: tab == 0
          ? FloatingActionButton.extended(
              backgroundColor: Colors.orange,
              foregroundColor: Colors.white,
              onPressed: _addAd,
              icon: const Icon(Icons.add),
              label: const Text('أضف إعلانك'),
            )
          : null,
    );
  }

  Widget _home() {
    final filtered = ads.where((a) {
      final q = search.trim().toLowerCase();
      return q.isEmpty ||
          a.title.toLowerCase().contains(q) ||
          a.category.toLowerCase().contains(q) ||
          a.city.toLowerCase().contains(q);
    }).toList();

    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            backgroundColor: const Color(0xFF1A365D),
            title: const Row(children: [
              Icon(Icons.storefront, color: Colors.orangeAccent),
              SizedBox(width: 8),
              Text('قادسية شوب', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ]),
            actions: [
              IconButton(
                color: Colors.white,
                icon: const Icon(Icons.notifications_outlined),
                onPressed: () => _snack('لا توجد إشعارات جديدة حالياً'),
              )
            ],
          ),
          SliverPadding(
            padding: const EdgeInsets.all(16),
            sliver: SliverList(delegate: SliverChildListDelegate([
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: .10),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.orange.withValues(alpha: .30)),
                ),
                child: const Row(children: [
                  Icon(Icons.info_outline, color: Colors.orange),
                  SizedBox(width: 10),
                  Expanded(child: Text(
                    'تنبيه: الدفع والشراء غير متاح عبر المحفظة الإلكترونية. التواصل والتفاهم مباشر بين البائع والمشتري.',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                  )),
                ]),
              ),
              const SizedBox(height: 16),
              TextField(
                textDirection: TextDirection.rtl,
                onChanged: (v) => setState(() => search = v),
                decoration: InputDecoration(
                  hintText: 'ابحث في قادسية شوب...',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 24),
              const Text('الأقسام الرئيسية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 105,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _category('إلكترونيات', Icons.phone_iphone),
                    _category('أزياء وموضة', Icons.checkroom),
                    _category('منزل وخدمات', Icons.miscellaneous_services),
                    _category('أجهزة منزلية', Icons.tv),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                const Text('أحدث الإعلانات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('${filtered.length} إعلان', style: const TextStyle(color: Colors.grey)),
              ]),
              const SizedBox(height: 10),
            ])),
          ),
          if (filtered.isEmpty)
            const SliverToBoxAdapter(child: Center(child: Padding(
              padding: EdgeInsets.all(40), child: Text('لا توجد نتائج'),
            )))
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList.builder(
                itemCount: filtered.length,
                itemBuilder: (_, i) => _adCard(filtered[i]),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 90)),
        ],
      ),
    );
  }

  Widget _category(String title, IconData icon) => GestureDetector(
    onTap: () => setState(() => search = title),
    child: Container(
      width: 105,
      margin: const EdgeInsets.only(left: 10),
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, size: 30, color: const Color(0xFF1A365D)),
        const SizedBox(height: 7),
        Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    ),
  );

  Widget _adCard(Ad ad) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AdDetailsScreen(ad: ad, onFavorite: () => setState(() => ad.favorite = !ad.favorite)))),
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(children: [
          Container(width: 78, height: 78, decoration: BoxDecoration(color: const Color(0xFFE9EEF5), borderRadius: BorderRadius.circular(10)),
            child: Icon(ad.icon, size: 36, color: const Color(0xFF1A365D))),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(ad.title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 5),
            Text(ad.price, style: const TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
            Text('${ad.city} • ${ad.category}', style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ])),
          IconButton(
            icon: Icon(ad.favorite ? Icons.favorite : Icons.favorite_border, color: ad.favorite ? Colors.red : Colors.grey),
            onPressed: () => setState(() => ad.favorite = !ad.favorite),
          ),
        ]),
      ),
    ),
  );

  Widget _favorites() {
    final favs = ads.where((a) => a.favorite).toList();
    return Scaffold(appBar: AppBar(title: const Text('المفضلة')), body: favs.isEmpty
      ? const Center(child: Text('لا توجد إعلانات في المفضلة'))
      : ListView(padding: const EdgeInsets.all(16), children: favs.map(_adCard).toList()));
  }

  Widget _profile() => Scaffold(
    appBar: AppBar(title: const Text('حسابي')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 45)),
      const SizedBox(height: 12),
      const Center(child: Text('مستخدم قادسية شوب', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
      const SizedBox(height: 25),
      _profileTile(Icons.add_box_outlined, 'إعلاناتي', () => _snack('ستظهر إعلاناتك هنا')),
      _profileTile(Icons.location_on_outlined, 'موقعي: الديوانية', () {}),
      _profileTile(Icons.settings_outlined, 'الإعدادات', () => _snack('الإعدادات قيد التطوير')),
    ]),
  );

  Widget _profileTile(IconData icon, String title, VoidCallback onTap) => Card(
    child: ListTile(leading: Icon(icon), title: Text(title), trailing: const Icon(Icons.chevron_left), onTap: onTap),
  );

  void _addAd() {
    final title = TextEditingController();
    final price = TextEditingController();
    final desc = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(left: 16, right: 16, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 20),
        child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('إضافة إعلان', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          TextField(controller: title, decoration: const InputDecoration(labelText: 'اسم المنتج')),
          TextField(controller: price, decoration: const InputDecoration(labelText: 'السعر')),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'الوصف'), maxLines: 3),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () {
              if (title.text.trim().isEmpty) return;
              setState(() => ads.insert(0, Ad(
                title: title.text.trim(),
                price: price.text.trim().isEmpty ? 'السعر عند التواصل' : price.text.trim(),
                city: 'الديوانية', category: 'عام',
                description: desc.text.trim().isEmpty ? 'تواصل مباشر مع البائع.' : desc.text.trim(),
                icon: Icons.shopping_bag_outlined,
              )));
              Navigator.pop(context);
              _snack('تمت إضافة الإعلان');
            },
            icon: const Icon(Icons.publish), label: const Text('نشر الإعلان'),
          )
        ])),
      ),
    );
  }

  void _snack(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class AdDetailsScreen extends StatelessWidget {
  final Ad ad;
  final VoidCallback onFavorite;
  const AdDetailsScreen({super.key, required this.ad, required this.onFavorite});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تفاصيل الإعلان'), actions: [
      IconButton(onPressed: onFavorite, icon: Icon(ad.favorite ? Icons.favorite : Icons.favorite_border))
    ]),
    body: ListView(padding: const EdgeInsets.all(20), children: [
      Container(height: 220, decoration: BoxDecoration(color: const Color(0xFFE9EEF5), borderRadius: BorderRadius.circular(18)),
        child: Icon(ad.icon, size: 90, color: const Color(0xFF1A365D))),
      const SizedBox(height: 20),
      Text(ad.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(ad.price, style: const TextStyle(fontSize: 20, color: Colors.orange, fontWeight: FontWeight.bold)),
      Text('${ad.city} • ${ad.category}', style: const TextStyle(color: Colors.grey)),
      const Divider(height: 32),
      const Text('الوصف', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Text(ad.description),
      const SizedBox(height: 30),
      FilledButton.icon(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
        icon: const Icon(Icons.chat),
        label: const Text('مراسلة البائع'),
      ),
    ]),
  );
}

class MessagesScreen extends StatelessWidget {
  const MessagesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المراسلات')),
    body: ListView(children: [
      ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: const Text('بائع تجريبي'), subtitle: const Text('مرحباً، هل المنتج متوفر؟'),
        trailing: const Text('الآن'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen()))),
    ]),
  );
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}
class _ChatScreenState extends State<ChatScreen> {
  final input = TextEditingController();
  final messages = <String>[];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المحادثة')),
    body: Column(children: [
      Expanded(child: ListView.builder(
        padding: const EdgeInsets.all(12), itemCount: messages.length,
        itemBuilder: (_, i) => Align(alignment: Alignment.centerRight, child: Container(
          margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFF1A365D), borderRadius: BorderRadius.circular(14)),
          child: Text(messages[i], style: const TextStyle(color: Colors.white)),
        )),
      )),
      SafeArea(child: Padding(padding: const EdgeInsets.all(8), child: Row(children: [
        Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'اكتب رسالة...', border: OutlineInputBorder()))),
        IconButton(icon: const Icon(Icons.send), onPressed: () {
          if (input.text.trim().isEmpty) return;
          setState(() { messages.add(input.text.trim()); input.clear(); });
        })
      ]))),
    ]),
  );
}

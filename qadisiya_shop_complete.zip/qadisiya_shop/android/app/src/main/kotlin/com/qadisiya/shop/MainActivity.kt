package com.qadisiya.shop

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
